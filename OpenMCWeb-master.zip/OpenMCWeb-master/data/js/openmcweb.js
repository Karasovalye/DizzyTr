$(document).ready(function() { //Bütüm sitenin hazır olmasını bekliyoruz
    //Bootstrap Material temasının Javascript eklentilerini çalıştırıyoruz.
    $.material.init();
});